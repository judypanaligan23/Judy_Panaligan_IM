﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUD_Information_Management
{
    public partial class Contacts : Form
    {
        private bool manwal = false;
        public Contacts()
        {
            InitializeComponent();
            this.KeyPreview = true;
            dtBirthday.ValueChanged += Birthday_ValueChanged;
            txtAge.TextChanged += Age_TextChanged;
        }
        private void Birthday_ValueChanged(object sender, EventArgs e)
        {
            if (!manwal)
            {
                DateTime birthday = dtBirthday.Value;
                int age = CalculateAge(birthday);
                txtAge.Text = age.ToString();
            }
        }
        private void Age_TextChanged(object sender, EventArgs e)
        {
            if (txtAge.Focused)
                manwal = true;
        }
        private int CalculateAge(DateTime BIRTHDAY)
        {
            DateTime today = DateTime.Today;
            int age = today.Year - BIRTHDAY.Year;

            if (BIRTHDAY.Date > today.AddYears(-age))
                age--;

            return age;
        }
        private void birthday_Reset(object sender, EventArgs e)
        {
            manwal = false;
        }
        private void Contacts_Load(object sender, EventArgs e)
        {
            AddReq();
            txtSearchName.Text = "Search name...";
            txtSearchName.ForeColor = Color.Gray;

            txtSearchName.GotFocus += RemoveText;
            txtSearchName.LostFocus += AddText;
        }

        private void RemoveText (object sender, EventArgs e)
        {
            if(txtSearchName.Text == "Search name...")
            {
                txtSearchName.Text = "";
                txtSearchName.ForeColor = Color.Black;
            }
        }

        private void AddText(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearchName.Text))
            {
                txtSearchName.Text = "Search name...";
                txtSearchName.ForeColor = Color.Gray;
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string gender = cmbGender.Text;
            string age = txtAge.Text;
            string birthday = dtBirthday.Text;
            string purpose = txtPurpose.Text;
            DateTime birth = dtBirthday.Value;
            DateTime today = DateTime.Today;

            int age1 = today.Year - birth.Year;

            if (birth.Date > today.AddYears(-age1))
            {
                age1--;
            }
            txtAge.Text = age1.ToString();

            if (name == "" || gender == "" || age == "" || birthday == "" || purpose == "")
            {
                MessageBox.Show("Please fill all fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = "INSERT INTO tblReq (Name, Gender, Age, Birthday, Purpose) " +
                        "VALUES (@Name, @Gender, @Age, @Birthday, @Purpose)";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@Age", age);
                        cmd.Parameters.AddWithValue("@Birthday", birthday);
                        cmd.Parameters.AddWithValue("@Purpose", purpose);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Request Added Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Adding Request: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            AddReq();
            txtName.Clear();
            cmbGender.SelectedIndex = -1;
            txtAge.Clear();
            dtBirthday.Format = DateTimePickerFormat.Short;
            txtPurpose.Clear();
        }

        private void AddReq()
        {
            using (var conn = Database.Get())
            {
                conn.Open();
                string query = "SELECT * FROM tblREq";
                using (var cmd = new MySqlCommand(query, conn))
                {
                    using (var adapter = new MySqlDataAdapter(cmd))
                    {
                        var table = new System.Data.DataTable();
                        adapter.Fill(table);
                        dataGridView1.DataSource = table;
                    }
                }
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a request to delete", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["ID"].Value);

                DialogResult result = MessageBox.Show("Are you sure you want to delete this?", "Confrim Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    using (var conn = Database.Get())
                    {
                        conn.Open();
                        string query = "DELETE FROM tblReq WHERE ID =@ID";

                        using (var cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@ID", ID);
                            cmd.ExecuteNonQuery();
                        }
                    }
                }
                else
                {
                    return;
                }

                MessageBox.Show("Request Deleted Successfully", "Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AddReq();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Deleting Request" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string id = txtID.Text;
            string name = txtName.Text;
            string gender = cmbGender.Text;
            string age = txtAge.Text;
            string birthday = dtBirthday.Text;
            string purpose = txtPurpose.Text;

            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = @"UPDATE tblReq SET Name = @Name, Gender = @Gender, Age = @Age, Birthday = @Birthday, Purpose = @Purpose WHERE ID = @ID";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ID", id);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@Age", age);
                        cmd.Parameters.AddWithValue("@Birthday", birthday);
                        cmd.Parameters.AddWithValue("@Purpose", purpose);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("Student Info Updated Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("Invalid Student ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                AddReq();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Updating Record" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                using (var conn = Database.Get())
                {
                    conn.Open();
                    string query = "SELECT * FROM tblReq WHERE Name = @Name";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Name", txtSearchName.Text);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string name = reader["Name"].ToString();
                                string gender = reader["Gender"].ToString();
                                string age = reader["Age"].ToString();
                                string birthday = reader["Birthday"].ToString();
                                string purpose = reader["Purpose"].ToString();


                                MessageBox.Show("Request Information\n\n" + $"Name: {name}\n" + $"Gender: {gender}\n" + $"Age: {age}\n" + $"Birthday: {birthday}\n" + $"Purpose: {purpose}\n",  "Contact Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("No Request Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }

                AddReq();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Searching Request" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void txtName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                cmbGender.Focus();
            }
        }

        private void cmbGender_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtAge.Focus();
            }
        }

        private void txtAge_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                dtBirthday.Focus();
            }
        }

        private void dtBirthday_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtPurpose.Focus();
            }
        }

        private void txtPurpose_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                BtnAdd.Focus();
            }
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtID.Text = row.Cells["ID"].Value.ToString();
                txtName.Text = row.Cells["Name"].Value.ToString();
                cmbGender.Text = row.Cells["Gender"].Value.ToString();
                txtAge.Text = row.Cells["Age"].Value.ToString();
                dtBirthday.Text = row.Cells["Birthday"].Value.ToString();
                txtPurpose.Text = row.Cells["Purpose"].Value.ToString();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
