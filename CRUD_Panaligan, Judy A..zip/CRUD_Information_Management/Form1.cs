﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using MySql.Data.MySqlClient;

namespace CRUD_Information_Management
{
    public partial class Form1: Form
    {
        SpeechSynthesizer voice = new SpeechSynthesizer();
        public Form1()
        {
            InitializeComponent();
        }
       
        private void btnContinue_Click(object sender, EventArgs e)
        {
            Contacts contact = new Contacts();
            contact.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            voice.SpeakAsync("Welcome to Requesting Indigency Management, Please Click button to Continue!");
            voice.Rate = -3;
        }
    }
}
