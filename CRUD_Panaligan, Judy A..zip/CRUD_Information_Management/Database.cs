﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace CRUD_Information_Management
{
    class Database
    {
        private static string connectionString = "server=localhost;uid=root;pwd=admin123;database=db_request;";

        public static MySqlConnection Get()
        {
            return new MySqlConnection(connectionString);
        }
    }
}
